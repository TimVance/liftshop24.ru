<?php
/**
 * Подключение модуля «Уведомления» для работы с отложенной отправкой сообщений
 *
 * @package    DIAFAN.CMS
 * @author     diafan.ru
 * @version    6.0
 * @license    http://www.diafan.ru/license.html
 * @copyright  Copyright (c) 2003-2018 OOO «Диафан» (http://www.diafan.ru/)
 */

if ( ! defined('DIAFAN'))
{
	$path = __FILE__;
	while(! file_exists($path.'/includes/404.php'))
	{
		$parent = dirname($path);
		if($parent == $path) exit;
		$path = $parent;
	}
	include $path.'/includes/404.php';
}

/**
 * Postman_inc_defer
 */
class Postman_inc_defer extends Diafan
{
	const URL = 'postman/send/';

	/**
	 * Инициирует отложенную отправку уведомлений
	 *
	 * @return void
	 */
	public function init()
	{
		if($this->diafan->configmodules('auto_send', 'postman') && $this->diafan->_postman->db_count_sent() > 0)
		{
			$this->fast_request(BASE_PATH.self::URL);
		}
	}

	/**
	 * Инициализация быстрого запроса
	 *
	 * @param string $url URL-адрес
	 * @return void
	 */
	private function fast_request($url)
	{
		$parts=parse_url($url);
		$parts['port'] = (isset($parts['port']) ? $parts['port'] : (getenv('SERVER_PORT') ?: 80));
		$fp = @fsockopen($parts['host'], $parts['port'], $errno, $errstr, 30);
		$out = "GET ".$parts['path']." HTTP/1.1\r\n";
		$out.= "Host: ".$parts['host']."\r\n";
		$out.= "Content-Length: 0"."\r\n";
		$out.= "Connection: Close\r\n\r\n";

		fwrite($fp, $out);
		fclose($fp);
	}
}

/**
 * Postman_message_exception
 *
 * Исключение для почтовых отправлений
 */
class Postman_defer_exception extends Exception{}
