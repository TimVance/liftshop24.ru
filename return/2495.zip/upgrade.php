<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {addons} ADD `sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'подрядковый номер для сортировки';");
DB::query("CREATE TABLE {postman} (`master_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'главный идентификатор в формате UNIXTIME', `slave_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'вторичный идентификатор в интервале master_id', `id` TEXT COMMENT 'объединенный идентификатор', `type` ENUM('mail', 'sms') NOT NULL DEFAULT 'mail' COMMENT 'тип уведомления: mail - электронные письма, sms - короткие сообщения', `recipient` TEXT COMMENT 'получатель/получатели', `subject` TEXT COMMENT 'тема письма', `body` TEXT COMMENT 'содержание письма', `from` TEXT COMMENT 'адрес отправителя', `auto` ENUM('0', '1') NOT NULL DEFAULT '1' COMMENT 'метод отправки уведомления: 0 - ручной, 1 - автоматический', `timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME', `timesent` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время отправки уведомления в формате UNIXTIME', `status` ENUM('0', '1', '2') NOT NULL DEFAULT '0' COMMENT 'отчет об отправке уведомления: 0 - не отправлено, 1 - отрпавлено, 2 - ошибка отправления', PRIMARY KEY (`master_id`, `slave_id`)) CHARSET=utf8 COMMENT 'Уведомления'");
DB::query("INSERT INTO {modules} (`id`, `name`, `module_name`, `site`, `site_page`, `admin`, `title`) VALUES (NULL, 'postman', 'core', '1', '0', '1', 'Уведомления');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '0', '2', '3', 'Уведомления', 'postman', '1', '0', '', '40', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, (SELECT e.id  FROM {admin} AS e WHERE e.`rewrite` LIKE 'postman' ORDER BY id ASC LIMIT 1), '0', '3', 'Список отправлений', 'postman', '1', '0', '', '1', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, (SELECT e.id  FROM {admin} AS e WHERE e.`rewrite` LIKE 'postman' ORDER BY id ASC LIMIT 1), '0', '3', 'Настройки', 'postman/config', '0', '0', '', '1', '');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'postman', 'mail_defer', '0', '1', '0');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'postman', 'sms_defer', '0', '1', '0');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'postman', 'del_after_send', '0', '1', '0');");
DB::query("INSERT INTO {config} (`id`, `module_name`, `name`, `lang_id`, `value`, `site_id`) VALUES (NULL, 'postman', 'auto_send', '0', '1', '0');");

