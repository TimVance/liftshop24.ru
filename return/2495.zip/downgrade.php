<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {addons} DROP `sort`;");
DB::query("DROP TABLE IF EXISTS {postman};");
DB::query("DELETE FROM {admin} WHERE `rewrite` REGEXP '^postman(/.*)?$';");