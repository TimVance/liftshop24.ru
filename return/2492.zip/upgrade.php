<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {ab_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {news_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {clauses_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {faq_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {shop_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {photo_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {files_category} ADD `view_rows` VARCHAR(50) NOT NULL DEFAULT '' COMMENT 'шаблон модуля для элементов в списке категории';");
DB::query("ALTER TABLE {update_return} ADD `version` VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'версия сборки';");