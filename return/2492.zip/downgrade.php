<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {ab_category} DROP `view_rows`;");
DB::query("ALTER TABLE {news_category} DROP `view_rows`;");
DB::query("ALTER TABLE {clauses_category} DROP `view_rows`;");
DB::query("ALTER TABLE {faq_category} DROP `view_rows`;");
DB::query("ALTER TABLE {shop_category} DROP `view_rows`;");
DB::query("ALTER TABLE {photo_category} DROP `view_rows`;");
DB::query("ALTER TABLE {files_category} DROP `view_rows`;");
DB::query("ALTER TABLE {update_return} DROP `version`;");