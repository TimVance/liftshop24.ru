<?php
if (! defined('DIAFAN'))
{
	exit;
}