<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("CREATE TABLE IF NOT EXISTS {addons} (
`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'идентификатор',
`addon_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор дополнения',
`custom_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'идентификатор из таблицы {custom}',
`name` VARCHAR(100) NOT NULL DEFAULT '' COMMENT 'название',
`anons` TEXT COMMENT 'анонс',
`text` TEXT COMMENT 'описание',
`install` TEXT COMMENT 'описание установки дополнения',
`link` VARCHAR( 255 ) NOT NULL DEFAULT '' COMMENT 'внешняя ссылка',
`image` VARCHAR( 255 ) NOT NULL DEFAULT '' COMMENT 'внешняя ссылка на изображение',
`author` TEXT COMMENT 'данные об авторе',
`author_link` TEXT COMMENT 'ссылка на страницу автора',
`sort` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'порядковый номер для сортировки',
`downloaded` INT(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'количество скачиваний',
`timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME',
`custom_timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'время последнего изменения в формате UNIXTIME в таблице {custom}',
`import_update` ENUM('0', '1') NOT NULL DEFAULT '0' COMMENT 'метка обновления записи: 0 - нет, 1 - да',
PRIMARY KEY (id),KEY addon_id (`addon_id`),KEY custom_id (`custom_id`)
) CHARSET=utf8 COMMENT 'Дополнения для CMS'");
DB::query("INSERT INTO {modules} (`id`, `name`, `module_name`, `site`, `site_page`, `admin`, `title`) SELECT * FROM (SELECT NULL AS id, 'addons' AS name, 'core' AS module_name, '0' AS site, '0' AS site_page, '1' AS admin, 'Дополнения' AS title) AS tmp WHERE NOT EXISTS (SELECT `name` FROM {modules} WHERE `name`='addons') LIMIT 1");
DB::query("UPDATE {modules} SET `module_name`='core', `site`='0', `site_page`='0', `admin`='1', `title`='Дополнения' WHERE `name`='addons'");
DB::query("DELETE FROM {admin} WHERE `rewrite` REGEXP '^addons(/.*)?$';");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, '0', '1', '3', 'Дополнения для CMS', 'addons', '1', '0', '', '39', '');");
DB::query("INSERT INTO {admin} (`id`, `parent_id`, `count_children`, `group_id`, `name`, `rewrite`, `act`, `add`, `add_name`, `sort`, `docs`) VALUES (NULL, (SELECT e.id  FROM {admin} AS e WHERE e.`rewrite` LIKE 'addons' ORDER BY id ASC LIMIT 1), '0', '3', 'Каталог дополнений', 'addons', '1', '0', '', '1', '');");