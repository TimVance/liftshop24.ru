<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {shop_param} DROP `site_id`;");
DB::query("ALTER TABLE {ab_param} DROP `site_id`;");