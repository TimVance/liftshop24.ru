<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {shop_param} ADD `site_id` INT(11) UNSIGNED NOT NULL DEFAULT '0';");
DB::query("ALTER TABLE {ab_param} ADD `site_id` INT(11) UNSIGNED NOT NULL DEFAULT '0';");