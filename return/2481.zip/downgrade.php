<?php
if (! defined('DIAFAN'))
{
	exit;
}
foreach($this->diafan->_languages->all as $l)
{
	DB::query("ALTER TABLE {tags_name} DROP `text".$l["id"]."`, DROP `keywords".$l["id"]."`, DROP `descr".$l["id"]."`, DROP `title_meta".$l["id"]."`;");
}
DB::query("ALTER TABLE {tags_name} DROP `timeedit`;");

$adminsite_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='shop/cart'");

DB::query("UPDATE {admin} SET count_children=count_children-1 WHERE id=%d", $adminsite_parent_id);
DB::query("DELETE FROM {admin} WHERE id=%d", $adminsite_id);
DB::query("DELETE FROM {admin_parents} WHERE element_id=%d", $adminsite_id);