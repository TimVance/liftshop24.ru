<?php
if (! defined('DIAFAN'))
{
	exit;
}
foreach($this->diafan->_languages->all as $l)
{
	DB::query("ALTER TABLE {tags_name} ADD `text".$l["id"]."` TEXT, ADD `keywords".$l["id"]."` VARCHAR(250) NOT NULL DEFAULT '', ADD `descr".$l["id"]."` TEXT, ADD `title_meta".$l["id"]."` VARCHAR(250) NOT NULL DEFAULT '';");
}
DB::query("ALTER TABLE {tags_name} ADD `timeedit` INT(10) UNSIGNED NOT NULL DEFAULT '0';");

$adminsite_parent_id = DB::query_result("SELECT id FROM {admin} WHERE rewrite='shop/ordercount' AND parent_id=0");
if($adminsite_parent_id)
{
	$adminsite_id = DB::query("INSERT INTO {admin} (parent_id, group_id, name, rewrite, act) VALUES (%d, '4', 'Брошенные корзины', 'shop/cart', '1')", $adminsite_parent_id);
	
	DB::query("INSERT INTO {admin_parents} (parent_id, element_id) VALUES (%d, %d)", $adminsite_parent_id, $adminsite_id);
	DB::query("UPDATE {admin} SET count_children=count_children+1 WHERE id=%d", $adminsite_parent_id);
}