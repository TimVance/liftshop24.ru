<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {shop} DROP `google`, DROP `show_google`;");
DB::query("ALTER TABLE {shop_category} DROP `show_google`;");