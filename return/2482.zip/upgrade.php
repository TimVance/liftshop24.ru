<?php
if (! defined('DIAFAN'))
{
	exit;
}
DB::query("ALTER TABLE {shop} ADD `google` TEXT, ADD `show_google` ENUM( '0', '1' ) NOT NULL DEFAULT '0';");
DB::query("ALTER TABLE {shop_category} ADD `show_google` ENUM( '0', '1' ) NOT NULL DEFAULT '0';");